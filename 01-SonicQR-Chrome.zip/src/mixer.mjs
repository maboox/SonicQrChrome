import { modulate, PROFILES, SAMPLE_RATE, crc16 } from './codec.mjs';
// MAIN-world hook. Idle recorders pass through without capturing or opening a microphone.
const KEY = '__sonicQRMixerV1__';
if (!globalThis[KEY] && typeof globalThis.MediaRecorder === 'function') {
  const Native = globalThis.MediaRecorder;
  let armed = null, latest = null, expires = null;
  const sessions = new Set();
  let last = { phase: 'idle', duration: 0, elapsed: 0, detail: '' };
  function clearArm() { armed = null; clearTimeout(expires); }
  function snapshot() {
    if (armed && Date.now() > armed.expiresAt) { clearArm(); last = { ...last, phase: 'expired' }; }
    if (latest && !latest.closed && latest.startedAt != null && !latest.complete && !latest.interrupted) {
      return { phase: latest.context.state === 'running' ? 'recording' : 'waiting', active: true, duration: latest.duration, elapsed: Math.max(0, Math.min(latest.duration, latest.context.currentTime - latest.startedAt)), detail: '' };
    }
    return { ...last, active: sessions.size > 0 };
  }
  function validate(config) {
    const p = Uint8Array.from(config?.packet || []);
    if (!Array.isArray(config?.packet) || config.packet.some(x => !Number.isInteger(x) || x < 0 || x > 255) || p.length < 9 || p.length > 2045 || p[0] !== 83 || p[1] !== 81 || p[2] !== 3 || p[3] !== PROFILES[config.profile]?.id || p[4] & ~3 || p.length !== 9 + p[5] * 256 + p[6] || crc16(p.subarray(0, -2)) !== p.at(-2) * 256 + p.at(-1)) throw new Error('invalidPacket');
    if (!Number.isFinite(config.amplitude) || config.amplitude < 0.025 || config.amplitude > (config.profile === 'hidden' ? 0.12 : 0.42)) throw new Error('invalidPacket');
    return { ...config, packet: p, expiresAt: Date.now() + 120000 };
  }
  function buildMix(stream, config) {
    const samples = modulate(config.packet, config.profile, config.amplitude);
    const context = new AudioContext({ sampleRate: SAMPLE_RATE });
    try {
    const output = context.createMediaStreamDestination();
    output.channelCount = 1;
    const source = context.createMediaStreamSource(stream);
    const voice = context.createGain(); voice.gain.value = 0.56;
    const toneGain = context.createGain();
    const tone = context.createBufferSource();
    const buffer = context.createBuffer(1, samples.length, SAMPLE_RATE);
    buffer.copyToChannel(samples, 0); tone.buffer = buffer;
    source.connect(voice); voice.connect(output); tone.connect(toneGain); toneGain.connect(output);
    const s = { context, output, source, voice, toneGain, tone, stream, duration: samples.length / SAMPLE_RATE, startedAt: null, complete: false, interrupted: false, closed: false, guard: null };
    sessions.add(s); latest = s;
    const inputs = stream.getAudioTracks();
    const mixed = output.stream.getAudioTracks()[0];
    const nativeStop = mixed.stop.bind(mixed);
    mixed.stop = () => { inputs.forEach(track => track.stop()); nativeStop(); cleanup(s); };
    inputs.forEach(track => track.addEventListener('ended', () => cleanup(s), { once: true }));
    tone.onended = () => {
      if (!s.closed && !s.interrupted) { s.complete = true; last = { phase: 'complete', duration: s.duration, elapsed: s.duration, detail: '' }; }
    };
    // Respect a host's microphone mute. Never monitor the microphone through speakers.
    s.guard = setInterval(() => {
      const enabled = inputs.some(track => track.enabled && track.readyState === 'live');
      toneGain.gain.value = enabled ? 1 : 0;
      if (!inputs.some(track => track.readyState === 'live')) cleanup(s);
    }, 100);
    return s;
    } catch (error) { void context.close().catch(() => {}); throw error; }
  }
  function interrupt(s) {
    if (s.closed || s.complete || s.interrupted) return;
    s.interrupted = true;
    try { s.tone.stop(); } catch {}
    last = { phase: 'incomplete', duration: s.duration, elapsed: s.startedAt == null ? 0 : Math.max(0, s.context.currentTime - s.startedAt), detail: '' };
  }
  function cleanup(s) {
    if (s.closed) return;
    interrupt(s); s.closed = true;
    clearInterval(s.guard);
    s.output.stream.getTracks().forEach(track => MediaStreamTrack.prototype.stop.call(track));
    s.source.disconnect(); s.voice.disconnect(); s.tone.disconnect();
    void s.context.close().catch(() => {});
    sessions.delete(s);
  }
  class VoiceRecorder extends Native {
    constructor(stream, options) {
      let s = null;
      snapshot();
      if (armed && stream instanceof MediaStream && stream.getAudioTracks().length && !stream.getVideoTracks().length && !stream.getAudioTracks().some(track => track.getSettings().displaySurface)) {
        const config = armed;
        try { s = buildMix(stream, config); clearArm(); last = { phase: 'waiting', duration: s.duration, elapsed: 0, detail: '' }; }
        catch (error) { clearArm(); last = { phase: 'error', duration: 0, elapsed: 0, detail: error.message }; }
      }
      try { super(s ? s.output.stream : stream, options); }
      catch (error) { if (s) cleanup(s); throw error; }
      this.sonicSession = s;
      if (s) {
        this.addEventListener('stop', () => cleanup(s));
        this.addEventListener('pause', () => interrupt(s));
        this.addEventListener('error', () => cleanup(s));
      }
    }
    start(...args) {
      const s = this.sonicSession;
      let result;
      try { result = super.start(...args); }
      catch (error) { if (s) cleanup(s); throw error; }
      if (s && s.startedAt == null && !s.closed) {
        // Schedule after MediaRecorder starts, so its recording includes the preamble.
        s.startedAt = s.context.currentTime + 0.25;
        s.tone.start(s.startedAt);
        void s.context.resume().catch(error => { interrupt(s); last = { phase: 'error', duration: s.duration, elapsed: 0, detail: error.message }; });
      }
      return result;
    }
  }
  globalThis.MediaRecorder = VoiceRecorder;
  Object.defineProperty(globalThis, KEY, { configurable: false, value: Object.freeze({
    version: 1,
    arm(config) {
      if (sessions.size) throw new Error('recordingBusy');
      armed = validate(config); clearTimeout(expires);
      last = { phase: 'armed', duration: modulate(armed.packet, armed.profile, armed.amplitude).length / SAMPLE_RATE, elapsed: 0, detail: '' };
      expires = setTimeout(() => { if (armed) { clearArm(); last.phase = 'expired'; } }, 120000);
      return snapshot();
    },
    disarm() { clearArm(); sessions.forEach(interrupt); if (!sessions.size) last = { phase: 'idle', duration: 0, elapsed: 0, detail: '' }; return snapshot(); },
    status: snapshot
  }) });
  addEventListener('pagehide', () => { clearArm(); sessions.forEach(cleanup); });
}
